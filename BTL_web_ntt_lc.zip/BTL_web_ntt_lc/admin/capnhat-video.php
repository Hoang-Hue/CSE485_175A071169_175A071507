<?php
	include 'db.php';
	$id=$_POST['id_video'];
	$tieude=$_POST['tieude'];
	$link=$_POST['link'];
	$sql = "UPDATE `video` SET `tieude`='$tieude',`link`='$link'
	WHERE id_video=$id ";
	if (mysqli_query($con, $sql)) {
		echo 'Thêm thành công';
	}
?>