<?php 
  include 'col-right.php';
 ?>
  <title>Video</title>  
  <br /><br />  
  <div class="container">  
   <h3 align="center">Danh sách video</h3>  
   <br />
   <div align="left">
    <button type="button" name="add" id="add" class="btn btn-success">Add</button>
   </div>
   <br />
   <table class="table table-bordered table-striped" >
    <thead>
      <tr>
        <th width="5%">ID</th>
        <th width="40%">Tiêu đề</th>
        <th width="40%">Link</th>
        <th width="5%">Edit</th>
        <th width="5%">Delete</th>
      </tr>
    </thead>
    <tbody id="video_data">
      
    </tbody>
  </table>
  </div>  
  <!-- dang ki -->
<div id="videoModal" class="modal fade" role="dialog">
 <div class="modal-dialog">
  <div class="modal-content">
   <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal">&times;</button> 
    </div>
    <div class="modal-body">
    <form id="video_form" method="POST" class="form-group">
     <input type="text" name="tieude" id="tieude" placeholder="Tiêu Đề"><p></p>
     <input type="text" name="link" id="link" placeholder="Đường truyền"><p></p>
     <input type="hidden" name="id_video" id="id_video" /><p></p>
     <input type="submit" name="insert" id="insert" value="Insert" class="btn btn-info" />
    </form>
   </div>
  </div>
 </div>
</div>


<!--  Update-->
    <div class="modal fade" id="update_country" role="dialog">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">
      <div class="modal-header" style="color:back;padding:6px;">
        <h5 class="modal-title"><i class="fa fa-edit"></i> Update</h5>
       <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <form method="POST" id="update_form"> 
      <div class="modal-body">
        <form method="POST" id="update_form"> 
        <!--1-->
             <label>Tiêu đề</label>
            <input type="text" name="tieude_modal" id="tieude_modal" class="form-control" required>   
          <!--2-->
            <label>Link</label>
            <input type="text" name="link_modal" id="link_modal" class="form-control" required>
            <p></p>
            <input type="hidden" name="id_video_modal" id="id_video_modal" class="form-control-sm">
            <button type="submit" id="update" class="btn btn-default btn-sm" style="background-color: #e35f14;color:#fff;">Save</button>
         </form>
      </div>
    </div>
  </div>
<!-- Modal End-->
<script>
$(document).ready(function(){
 
 
 fetch_data(); 

 function fetch_data()
 {
  $.ajax({
   url:"xuathien-video.php",
   method:"POST",
   data:{},
   success:function(data)
   {
    $('#video_data').html(data);
   }
  })
 }
// sưa
$(document).on("click", "#update", function() { 
    $.ajax({
      url: "capnhat-video.php",
      type: "POST",
      cache: false,
      data:{
        id_video: $('#id_video_modal').val(),
        tieude: $('#tieude_modal').val(),
        link: $('#link_modal').val(),
      },
      success: function(dataResult){
        var dataResult = JSON.parse(dataResult);
        if(dataResult.statusCode==200){
          $('#update_country').modal().hide();
          alert('Data updated successfully !');
          location.reload();          
        }
      }
    });
  }); 
 //hien form 
$('#add').click(function(e) {
  
  $('#videoModal').modal('show');
  $('#video_form')[0].reset();

});
//them
$("#video_form").submit(function (event) {
                event.preventDefault();
            var formData = new FormData($(this)[0]);
            $.ajax({
                url: 'them-video.php',
                type: 'POST',
                data: formData,
                async: true,
                cache: false,
                contentType: false,
                processData: false,
                success: function (data) 
                {
                    alert(data);
                    fetch_data();
                    $('#video_form')[0].reset();
                    $('#videoModal').modal('hide');
                },
                error: function(){
                alert("error in ajax form submission");
                                    }
        });
        return false;
    });
//chọn
  
$(function () {
    $('#update_country').on('show.bs.modal', function (event) {
      var button = $(event.relatedTarget); /*Button that triggered the modal*/
      var id_video = button.data('id_video');
      var tieude = button.data('tieude');
      var link = button.data('link');
      var modal = $(this);
      modal.find('#id_video_modal').val(id_video);
      modal.find('#tieude_modal').val(tieude);
      modal.find('#link_modal').val(link);
    });
    });
 
 //xoa user-----thanhcong
 $(document).on('click', '.delete', function(){
  var id_video = $(this).attr("id");
  if(confirm("Bạn có chắc chắn muốn xóa?"))
  {
   $.ajax({
    url:"xoa-video.php",
    method:"POST",
    data:{id_video:id_video},
    success:function(data)
    {
     alert(data);
     fetch_data();
    }
   })
  }
  else
  {
   return false;
  }
 });
}); 

</script>