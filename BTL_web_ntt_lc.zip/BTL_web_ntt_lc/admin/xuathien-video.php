<?php 
	require 'db.php';
	$sql = "SELECT * FROM video";
					$result = mysqli_query($con, $sql);
					 $output = '
			        <table class="table table-bordered table-striped">
			        ';
					while($row = mysqli_fetch_array($result))
						  {
						   $output .= '
						    <tr>
						     <td>'.$row["id_video"].'</td>
						     <td>'.$row["tieude"].'</td>
						     <td>'.$row["link"].'</td>
						    <td><button button type="button" class="btn btn-warning btn-sm edit" data-toggle="modal" data-keyboard="false" data-backdrop="static" data-target="#update_country"
								data-id_video="'.$row['id_video'].'"
								data-tieude="'.$row['tieude'].'"
								data-link="'.$row['link'].'"
								
								">Edit</button></td>
						     <td><button type="button" name="delete" class="btn btn-danger bt-xs delete" id="'.$row["id_video"].'">Delete</button></td>
						    </tr>
						   ';
						  }
					$output .= '</table>';
					echo $output;
 ?>