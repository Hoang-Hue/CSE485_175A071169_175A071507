<?php 
	require 'db.php';
  $sql = "SELECT * FROM baiviet ";
  $result = mysqli_query($con, $sql);
  $output = '
   <table class="table table-bordered table-striped">  
    <tr>
     <th width="5%">ID</th>
     <th width="30%">Tiêu đề</th>
     <th width="40%">Tóm tắt</th>
     <th>Ảnh</th>
     <th width= "5%">Delete</th>
    </tr>
  ';
  while($row = mysqli_fetch_array($result))
  {
   $output .= '

    <tr>
     <td>'.$row["id_baiviet"].'</td>
     <td>'.$row["tieude"].'</td>
     <td>'.$row["tomtat"].'</td>
     <td>
      <img src="../admin/img/'.$row['anh'].'" height="60" width="75" class="img-thumbnail" />
     </td>
     <td><button type="button" name="delete" class="btn btn-danger bt-xs delete" id="'.$row["id_baiviet"].'"><i class="fas fa-trash-alt"></i></button></td>
    </tr>
   ';
  }
  $output .= '</table>';
  echo $output;
 ?>