<?php 
	require 'db.php';
	$sql = "SELECT * FROM user";
					$result = mysqli_query($con, $sql);
					 $output = '
			        <table class="table table-bordered table-striped">
			        ';
					while($row = mysqli_fetch_array($result))
						  {
						   $output .= '
						    <tr>
						     <td>'.$row["userid"].'</td>
						     <td>'.$row["hoten"].'</td>
						     <td>'.$row["email"].'</td>
						    <td>'.$row["user_level"].'</td>
						    <td><button button type="button" class="btn btn-warning btn-sm edit" data-toggle="modal" data-keyboard="false" data-backdrop="static" data-target="#update_country"
								data-userid="'.$row['userid'].'"
								data-hoten="'.$row['hoten'].'"
								data-email="'.$row['email'].'"
								data-user_level="'.$row['user_level'].'"
								">Edit</button></td>
						     <td><button type="button" name="delete" class="btn btn-danger bt-xs delete" id="'.$row["userid"].'">Delete</button></td>
						    </tr>
						   ';
						  }
					$output .= '</table>';
					echo $output;
 ?>