<?php

$hoten; $email; $password; $repassword;
        if(isset($_POST['hoten'])){
          $hoten=$_POST['hoten'];
        }
        if(isset($_POST['email'])){
          $email=$_POST['email'];
        }
        if(isset($_POST['password'])){
          $password=$_POST['password'];
        }
         if(isset($_POST['repassword'])){
          $password=$_POST['repassword'];
        }
        		require 'db.php';
        		$password = md5($password);
        		$sql = "INSERT INTO user (hoten,email, password) 
					VALUES ( '$hoten','$email', '$password')";    
				      if(mysqli_query($con, $sql))
				      {
				       header ("location: login.php"); 
				      }

?>