<?php 
	require 'db.php';
	$tieude =  $_POST['tieude'];
  $tomtat =  $_POST['tomtat'];
  $file = $_FILES["image"]["name"];
  $sql = "INSERT INTO baiviet (tieude,tomtat, anh) VALUES ( '$tieude','$tomtat','$file')";
      
      if(mysqli_query($con, $sql))
      {
       echo 'Thêm thành công';
      }
 ?>