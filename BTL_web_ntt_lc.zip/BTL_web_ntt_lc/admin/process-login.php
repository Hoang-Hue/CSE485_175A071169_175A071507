<?php 
    if(isset($_POST["login"]) && $_POST["email"] !='' && $_POST["password"] !='')
    {
        require  'db.php';
        
        mysqli_set_charset($con,'UTF8');
        
       
        $email  = $_POST['email'];
        $password  = $_POST['password'];
    
        $password = md5($password);
    
        $sqluser = "SELECT * FROM user WHERE email ='$email' AND password = '$password'";
        $result = mysqli_query($con,$sqluser);
  
        
        if (mysqli_num_rows($result) >0 ) {
            
             header("Location: page_admin.php ");
        }else{
            
            echo "Đăng nhập không thành công. ";
        }
    
    } else{
        if ($password == '') {
            echo 'Bạn chưa nhập mật khẩu';
        }
        if ($password == '') {
            echo 'Bạn chưa nhập mật khẩu';
        }
        header("Location: login.php");
      
    }
 ?>
