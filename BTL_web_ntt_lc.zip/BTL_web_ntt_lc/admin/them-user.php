<?php 
					require 'db.php';
					$hoten = $_POST['hoten'];
				 	$email = $_POST['email'];
				 	$password = $_POST['password'];
				 	$password = md5($password);
				 	$user_level = $_POST['user_level'];
					$sql = "INSERT INTO user (hoten, email, password, user_level) 
					VALUES ( '$hoten','$email', '$password','$user_level')";    
				      if(mysqli_query($con, $sql))
				      {
				       echo 'Thêm thành công';
				      }
 ?>