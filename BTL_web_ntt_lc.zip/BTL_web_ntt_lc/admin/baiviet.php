<?php 
  include 'col-right.php';
 ?>
  <title>Bài viết</title>  
  <br /><br />  
  <div class="container" style="width:900px;">  
   <h3 align="center">Danh sách bài viết</h3>  
   <br />
   <div align="right">
    <button type="button" name="add" id="add" class="btn btn-success">Add</button>
   </div>
   <br />
   <div id="baiviet_data">

   </div>
  </div>  
 </body>  
</html>

<div id="baivietModal" class="modal fade" role="dialog">
 <div class="modal-dialog">
  <div class="modal-content">
   <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal">&times;</button>
   </div>
   <div class="modal-body">
    <form id="baiviet_form" method="post" enctype="multipart/form-data">

         <input type="text" name="tieude" id="tieude" ><p></p>
         <input type="textarea" name="tomtat" id="tomtat"><p></p>
         <p><label>Mời chọn ảnh</label>
         <input type="file" name="image" id="image" /></p><br />
         <input type="hidden" name="action" id="action" value="insert" />
         <input type="submit" name="insert" id="insert" value="Insert" class="btn btn-info" />
      
    </form>
   </div>
  </div>
 </div>
</div>
 
<script>

$(document).ready(function(){
 
 fetch_data(); 
 function fetch_data()
 {
  $.ajax({
   url:"xuathien-baiviet.php",
   method:"POST",
   data:{},
   success:function(data)
   {
    $('#baiviet_data').html(data);
   }
  })
 }

 $('#add').click(function(){
  $('#baivietModal').modal('show');
  $('#baiviet_form')[0].reset();  
 });
 $('#baiviet_form').submit(function(event){
  event.preventDefault();
  var tieude = $('#tieude').val();
  var tomtat = $('#tomtat').val();
  var anh = $('#image').val();

  if( anh == '')
  {
   alert("Làm ơn chọn ảnh");
   return false;
  }
  else
  {
   var extension = $('#image').val().split('.').pop().toLowerCase();
   if(jQuery.inArray(extension, ['gif','png','jpg','jpeg']) == -1)
   {
    alert("Chọn file ảnh đúng định dạng");
    
    $('#tieude').val('');
    $('#tomtat').val('');
    $('#image').val('');

    return false;
   }
   else
   {
    $.ajax({
     url:"them-baiviet.php",
     method:"POST",
     data:new FormData(this),
     contentType:false,
     processData:false,
     success:function(data)
     {
      alert(data);
      fetch_data();
      $('#baiviet_form')[0].reset();
      $('#baivietModal').modal('hide');
     }
    });
   }
  }
 });
 
////
 
 //xoa anh-----thanhcong
 $(document).on('click', '.delete', function(){
  var id_baiviet = $(this).attr("id");
  if(confirm("Bạn có chắc chắn muốn xóa?"))
  {
   $.ajax({
    url:"xoa-baiviet.php",
    method:"POST",
    data:{id_baiviet:id_baiviet},
    success:function(data)
    {
     alert(data);
     fetch_data();
    }
   })
  }
  else
  {
   return false;
  }
 });
});  
</script>
