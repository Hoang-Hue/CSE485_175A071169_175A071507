<?php 
	
	require 'db.php';

	 	$sql = "DELETE FROM video WHERE id_video = '".$_POST["id_video"]."'";
				if(mysqli_query($con, $sql))
				  {
				   echo 'Xóa thành công';
				  }
 ?>