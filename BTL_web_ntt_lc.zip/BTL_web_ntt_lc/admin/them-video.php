<?php 
					require 'db.php';
					$tieude = $_POST['tieude'];
				 	$link = $_POST['link'];
					$sql = "INSERT INTO video (tieude, link) 
					VALUES ( '$tieude','$link')";    
				      if(mysqli_query($con, $sql))
				      {
				       echo 'Thêm thành công';
				      }
 ?>