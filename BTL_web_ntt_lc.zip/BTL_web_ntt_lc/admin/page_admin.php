<?php 
  require 'col-right.php';
 ?>
 <?php 
 require 'top.php';
  ?>