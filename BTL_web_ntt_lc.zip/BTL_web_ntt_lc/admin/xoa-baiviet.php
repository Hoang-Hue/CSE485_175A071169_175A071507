<?php 
	require 'db.php';
	$sql = "DELETE FROM baiviet WHERE id_baiviet = '".$_POST["id_baiviet"]."'";
	  if(mysqli_query($con, $sql))
	  {
	   echo 'Xóa thành công';
	  }
 ?>