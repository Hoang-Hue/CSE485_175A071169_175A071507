// Empty JS for your own code to be here
$( document ).ready(function(){
    $('#menu-trigger').click(function(){
        $('#list').toggle();
    })
    $('.button-collapse').dropdown();
    });