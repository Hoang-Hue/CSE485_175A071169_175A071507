<?php
	include 'db.php';
	$id=$_POST['userid'];
	$hoten=$_POST['hoten'];
	$email=$_POST['email'];
	$user_level=$_POST['user_level'];
	$sql = "UPDATE `user` SET `hoten`='$hoten',`email`='$email',`user_level`='$user_level' 
	WHERE userid=$id ";
	if (mysqli_query($con, $sql)) {
		echo 'Thêm thành công';
	}
?>