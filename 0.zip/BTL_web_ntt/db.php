
<?php
    $con=mysqli_connect('localhost','root','','trangquantri1');
?>
