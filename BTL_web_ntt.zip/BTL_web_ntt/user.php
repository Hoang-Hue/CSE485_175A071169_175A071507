<?php 
  include 'col-right.php';
 ?>
  <title>User</title>  
  <br /><br />  
  <div class="container">  
   <h3 align="center">Danh sách người dùng</h3>  
   <br />
   <div align="left">
    <button type="button" name="add" id="add" class="btn btn-success">Add</button>
   </div>
   <br />
   <table class="table table-bordered table-striped" >
    <thead>
      <tr>
        <th width="5%">ID</th>
        <th width="40%">Họ tên</th>
        <th width="40%">Email</th>
        <th width="5%">User level</th>
        <th width="5%">Edit</th>
        <th width="5%">Delete</th>
      </tr>
    </thead>
    <tbody id="user_data">
      
    </tbody>
  </table>
  </div>  
  <!-- dang ki -->
<div id="userModal" class="modal fade" role="dialog">
 <div class="modal-dialog">
  <div class="modal-content">
   <div class="modal-header">
    <button type="button" class="close" data-dismiss="modal">&times;</button> 
    </div>
    <div class="modal-body">
    <form id="user_form" method="POST" class="form-group">
     <input type="text" name="hoten" id="hoten" placeholder="Họ Tên"><p></p>
     <input type="email" name="email" id="email" placeholder="Email"><p></p>
     <input type="password" name="password" id="password" placeholder="Mật khẩu"><p></p>
     <input type="text" name="user_level" id="user_level" placeholder="Quyền hạn"><p></p>
     <input type="hidden" name="userid" id="userid" /><p></p>
     <input type="submit" name="insert" id="insert" value="Insert" class="btn btn-info" />
    </form>
   </div>
  </div>
 </div>
</div>


<!--  Update-->
    <div class="modal fade" id="update_country" role="dialog">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">
      <div class="modal-header" style="color:back;padding:6px;">
        <h5 class="modal-title"><i class="fa fa-edit"></i> Update</h5>
       <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>
      <form method="POST" id="update_form"> 
      <div class="modal-body">
        <form method="POST" id="update_form"> 
        <!--1-->
             <label>Họ tên</label>
            <input type="text" name="hoten_modal" id="hoten_modal" class="form-control" required>   
          <!--2-->
            <label>Email</label>
            <input type="text" name="email_modal" id="email_modal" class="form-control" required>
        <!--4-->
            <label>User level</label>
            <input type="text" name="user_level_modal" id="user_level_modal" class="form-control" required>
            <p></p>
            <input type="hidden" name="userid_modal" id="userid_modal" class="form-control-sm">
            <button type="submit" id="update" class="btn btn-default btn-sm" style="background-color: #e35f14;color:#fff;">Save</button>
         </form>
      </div>
    </div>
  </div>
<!-- Modal End-->
<script>
$(document).ready(function(){
 
 
 fetch_data(); 

 function fetch_data()
 {
  $.ajax({
   url:"xuathien.php",
   method:"POST",
   data:{},
   success:function(data)
   {
    $('#user_data').html(data);
   }
  })
 }
// sưa
$(document).on("click", "#update", function() { 
    $.ajax({
      url: "capnhat-user.php",
      type: "POST",
      cache: false,
      data:{
        userid: $('#userid_modal').val(),
        hoten: $('#hoten_modal').val(),
        email: $('#email_modal').val(),
        user_level: $('#user_level_modal').val(),
      },
      success: function(dataResult){
        var dataResult = JSON.parse(dataResult);
        if(dataResult.statusCode==200){
          $('#update_country').modal().hide();
          alert('Data updated successfully !');
          location.reload();          
        }
      }
    });
  }); 
 //hien form 
$('#add').click(function(e) {
  
  $('#userModal').modal('show');
  $('#user_form')[0].reset();

});
//them
$("#user_form").submit(function (event) {
                event.preventDefault();
            var formData = new FormData($(this)[0]);
            $.ajax({
                url: 'them-user.php',
                type: 'POST',
                data: formData,
                async: true,
                cache: false,
                contentType: false,
                processData: false,
                success: function (data) 
                {
                    alert(data);
                    fetch_data();
                    $('#user_form')[0].reset();
                    $('#userModal').modal('hide');
                },
                error: function(){
                alert("error in ajax form submission");
                                    }
        });
        return false;
    });
//chọn
  
$(function () {
    $('#update_country').on('show.bs.modal', function (event) {
      var button = $(event.relatedTarget); /*Button that triggered the modal*/
      var userid = button.data('userid');
      var hoten = button.data('hoten');
      var email = button.data('email');
      var user_level = button.data('user_level');
      var modal = $(this);
      modal.find('#hoten_modal').val(hoten);
      modal.find('#email_modal').val(email);
      modal.find('#user_level_modal').val(user_level);
      modal.find('#userid_modal').val(userid);
    });
    });
 
 //xoa user-----thanhcong
 $(document).on('click', '.delete', function(){
  var userid = $(this).attr("id");
  if(confirm("Bạn có chắc chắn muốn xóa?"))
  {
   $.ajax({
    url:"xoa-user.php",
    method:"POST",
    data:{userid:userid},
    success:function(data)
    {
     alert(data);
     fetch_data();
    }
   })
  }
  else
  {
   return false;
  }
 });
}); 

</script>