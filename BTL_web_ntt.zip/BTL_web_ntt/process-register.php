<?php

$first_name; $last_name;$email; $password;$repassword;$captcha;
        if(isset($_POST['first_name'])){
          $first_name=$_POST['first_name'];
        }
        if(isset($_POST['last_name'])){
          $last_name=$_POST['last_name'];
        }
        if(isset($_POST['email'])){
          $email=$_POST['email'];
        }
        if(isset($_POST['password'])){
          $password=$_POST['password'];
        }
         if(isset($_POST['repassword'])){
          $password=$_POST['repassword'];
        }
        if(isset($_POST['g-recaptcha-response'])){
          $captcha=$_POST['g-recaptcha-response'];
        }
        if(!$captcha){
          echo '<h2>Kiểm tra lại captcha.</h2>';
          exit;
        }

        $secretKey = "6Lc2U78UAAAAAJxM5hJcxL_qvXUoUhJBB8dqLH6H";
        $ip = $_SERVER['REMOTE_ADDR'];
        // post request to server
        $url = 'https://www.google.com/recaptcha/api/siteverify?secret=' . urlencode($secretKey) .  '&response=' . urlencode($captcha);
        $response = file_get_contents($url);
        $responseKeys = json_decode($response,true);
        // should return JSON with success as true
        if($responseKeys["success"]) {
        		require 'db.php';
        		$password = md5($password);
        		$sql = "INSERT INTO user (first_name,last_name, email, password) 
					VALUES ( '$first_name','$last_name','$email', '$password')";    
				      if(mysqli_query($con, $sql))
				      {
				       header ("location: login.php"); 
				      }
        } else {
                echo '<h2>Lỗi ! Get the @$%K out</h2>';
        }

?>