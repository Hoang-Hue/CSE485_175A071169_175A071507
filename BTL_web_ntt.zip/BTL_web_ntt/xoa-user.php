<?php 
	
	require 'db.php';

	$sql= "SELECT * FROM user";
	$result = mysqli_query($con, $sql);
	while($row = mysqli_fetch_array($result))
	{	
	 if ($row["user_level"] == 1) {
	 			
	 			echo 'Không xóa đc';	 	
	 }	else {
	 	$sql = "DELETE FROM user WHERE userid = '".$_POST["userid"]."'";
				if(mysqli_query($con, $sql))
				  {
				   echo 'Xóa thành công';
				  }
	 }			 
	 }
 ?>